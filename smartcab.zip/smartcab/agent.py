import numpy as np
import operator
import random
import math
from environment import Agent, Environment
from planner import RoutePlanner
from simulator import Simulator

class LearningAgent(Agent):
    """ An agent that learns to drive in the Smartcab world.
        This is the object you will be modifying. """ 

    def __init__(self, env, learning=False, epsilon=1.0, alpha=0.5):
        super(LearningAgent, self).__init__(env)     # Set the agent in the evironment 
        self.planner = RoutePlanner(self.env, self)  # Create a route planner
        self.valid_actions = self.env.valid_actions  # The set of valid actions

        # Set parameters of the learning agent
        self.learning = learning # Whether the agent is expected to learn
        self.Q = dict()          # Create a Q-table which will be a dictionary of tuples
        self.epsilon = epsilon   # Random exploration factor
        self.alpha = alpha       # Learning factor
        ###########
        ## TO DO ##
        ###########
        
        # Set any additional class parameters as needed


    def reset(self, destination=None, testing=False):
        """ The reset function is called at the beginning of each trial.
            'testing' is set to True if testing trials are being used
            once training trials have completed. """

        # Select the destination as the new location to route to
        self.planner.route_to(destination)
        
        ########### 
        ## TO DO ##
        ##########
        self.alpha=0.95
        #self.alpha=0.8
        #self.alpha=0.7
        #self.alpha=0.6
        #self.alpha=0.5
        #self.alpha=0.1
        
        
        #self.epsilon-=0.05

        #MODELS TO DISPLAY
        
        #step based model with alpha as 0.7-MODEL 0
        '''if self.env.trial < 5:
            self.epsilon=0.4
        elif self.env.trial < 10:
            self.epsilon=0.2
        elif self.env.trial < 20:
            self.epsilon=0.1
        else:
            self.epsilon = np.exp(self.env.trial*-1)'''
        
        #MODEL 1
        #self.epsilon=np.exp(-0.1*self.env.trial)
        
        #MODEL 3
        #self.epsilon=np.cos(0.05*self.env.trial)-0.5 with alpha 0.7 with tolerance 0.000001
        #self.epsilon=np.cos(0.05*self.env.trial)-0.5
        
        #MODEL 4
        #self.epsilon=0.3**(self.env.trial**1) with alpha=0.7
        self.epsilon=0.9**(self.env.trial*0.8)
        
        #MODEL 7
        #self.epsilon=1/(self.env.trial**2+0.3*self.env.trial)
        
        #MODEL 8
        #self.epsilon=np.exp(-0.1*self.env.trial) with alpha as 0.8 and tolerance as 0.0001
        #MODEL 9
        #self.epsilon=1/(self.env.trial**2-0.5*self.env.trial) with tolerance 0.00001 and alpha 0.7
        #self.epsilon=1/(self.env.trial**2-0.5125*self.env.trial)
        #MODEL 10
        #self.epsilon=1/(self.env.trial**2+0.5*self.env.trial) with alpha 0.5
        #self.epsilon=1/(self.env.trial**2+0.5*self.env.trial)
        
        #To ensure that epsilon does not take a negative value or take a value above 1
        if self.epsilon > 1:
            self.epsilon = 1
        
        if self.epsilon < 0:
            self.epsilon = 0
        if testing == True:
            self.epsilon = 0
            self.alpha = 0
        
        # Update epsilon using a decay function of your choice
        # Update additional class parameters as needed
        # If 'testing' is True, set epsilon and alpha to 0
        return None

    
    
    def build_state(self):
        """ The build_state function is called when the agent requests data from the 
            environment. The next waypoint, the intersection inputs, and the deadline 
            are all features available to the agent. """

        # Collect data about the environment
        waypoint = self.planner.next_waypoint() # The next waypoint 
        inputs = self.env.sense(self)           # Visual input - intersection light and traffic
        deadline = self.env.get_deadline(self)  # Remaining deadline 
        
        # Function used to convert the None Keyword to a string
        def build_string(s):
                if s == None:
                    return 'None'
                else:
                    return s
           
        # State knowledge is converted to string, as otherwise, the tuple is not compatible with the pandas dataframe used for analysis
        state = build_string(waypoint)+" "+inputs['light']+" "+build_string(inputs['left'])+" "+build_string(inputs['right']) 
        
        return state


    
    def get_maxQ(self, state):
        """ The get_max_Q function is called when the agent is asked to find the
            maximum Q-value of all actions based on the 'state' the smartcab is in. """

        # Calculating maximum Q-value of all actions for a given state
        maxQ = -100000
        maxQ_action=None
        for action in self.Q[state]:
            if maxQ < self.Q[state][action]:
                maxQ = self.Q[state][action]
                maxQ_action = action
        
        #To convert the string into value NULL, to make it valid according to self.valid_actions
        if maxQ_action == 'None':
            maxQ_action=None
                
        return maxQ_action


    def createQ(self, state):
        """ The createQ function is called when a state is generated by the agent. """

        #Creating the Q-Table and adding the state in Q-Table if not extant.
        if self.learning == True:
            if state not in self.Q:
                self.Q[state] = {'forward':0.0,'right':0.0,'left':0.0,'None':0.0}
    
        return state

    

    def choose_action(self, state):
        """ The choose_action function is called when the agent is asked to choose
            which action to take, based on the 'state' the smartcab is in. """

        # Set the agent state and default action
        self.state = state
        self.next_waypoint = self.planner.next_waypoint()
        action = random.choice(self.valid_actions)
        

        # When not learning, choose a random action
        if self.learning == False:
            action = np.random.choice(self.valid_actions)
        else :
                
            action_num = np.random.choice((1,2),p = [self.epsilon,1-self.epsilon])
            #Explore at a probability of epsilon, or else follow the route according to Q-Table
            if action_num == 1:
                action = np.random.choice(self.valid_actions)
            else :
                action = self.get_maxQ(state)
                
        return action

    

    def learn(self, state, action, reward):
        """ The learn function is called after the agent completes an action and
            receives a reward. This function does not consider future rewards 
            when conducting learning. """
       
    #To convert the None keyword to string, so value can be updated in Q-Table
        def build_string(s):
                if s == None:
                    return 'None'
                else:
                    return s

        #Implementing the value iteration update rule
        #   Use only the learning rate 'alpha' (do not use the discount factor 'gamma')
        
        action=build_string(action)
        
        #Updating the Q_Table
        self.Q[state][action] = (1 - self.alpha)*(self.Q[state][action]) + (self.alpha)*(reward)
        return


    
    def update(self):
        """ The update function is called when a time step is completed in the 
            environment for a given trial. This function will build the agent
            state, choose an action, receive a reward, and learn if enabled. """

        state = self.build_state()          # Get current state
        self.createQ(state)                 # Create 'state' in Q-table
        action = self.choose_action(state)  # Choose an action
        reward = self.env.act(self,action) # Receive a reward
        self.learn(state, action, reward)   # Q-learn

        return
        

def run():
    """ Driving function for running the simulation. 
        Press ESC to close the simulation, or [SPACE] to pause the simulation. """

    ##############
    # Create the environment
    # Flags:
    env = Environment()
    env.verbose= False
    env.num_dummies = 80
    env.grid_size = (8,8)

    
    ##############
    # Create the driving agent
    # Flags:
    agent = env.create_agent(LearningAgent)
    agent.learning = True
    agent.epsilon = 1
    agent.alpha = 0.5
    
    
    ##############
    # Follow the driving agent
    # Flags:
    enforce_deadline = True 
    env.set_primary_agent(agent,enforce_deadline)

    ##############
    # Create the simulation
    # Flags:
    sim = Simulator(env)
    sim.update_delay = 0.00000001
    sim.display = False
    sim.log_metrics = True
    sim.optimized = True
    
    ##############
    # Run the simulator
    # Flags:
    tolerance = 0.000001
    n_test = 10
    sim.run(tolerance,n_test)


if __name__ == '__main__':
    run()

